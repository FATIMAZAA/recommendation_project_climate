from django.db import models
from django.contrib.auth.models import User

class EmissionFactor(models.Model):
    name = models.CharField(max_length=100)
    factor = models.FloatField()

    def __str__(self):
        return self.name



class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    

    
class MyModel(models.Model):
    field1 = models.CharField(max_length=100)
    field2 = models.IntegerField()

class Subscriber(models.Model):
    email = models.EmailField(unique=True)
    name = models.CharField(max_length=255)
    subscribed_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email
    


