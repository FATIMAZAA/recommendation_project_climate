from django.urls import path, include
from .import views
from .views import index, login_view, register_view, logout_view, blog_view, home_view



urlpatterns = [
    path('blog/', include('blog.urls')),
    path('index/', index, name='home'),
    path('login/', login_view, name='login'),
    path('register/', register_view, name='register'),
    path('logout/', logout_view, name='logout'),
    path('blog/', blog_view, name='blog'),
    path('home/', home_view, name='home'),
    path('subscribe/', views.subscribe, name='subscribe'),
    path('success/', views.success, name='success'),

   ]
