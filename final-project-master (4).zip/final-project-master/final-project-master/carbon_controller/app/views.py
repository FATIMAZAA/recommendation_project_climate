from django.shortcuts import render, redirect
from django.views import View
from .models import EmissionFactor
from django.contrib.auth.forms import UserCreationForm
from .models import MyModel
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from .forms import SubscriberForm


def success(request):
    return render(request, 'success.html')

def subscribe(request):
    if request.method == 'POST':
        form = SubscriberForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('success')  # Redirect to a success page
    else:
        form = SubscriberForm()
    
    return render(request, 'subscribe.html', {'form': form})
def view_data(request):
    data = MyModel.objects.all()
    return render(request, 'data_view.html', {'data': data})

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'register/index.html', {'form': form})


def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})


emission_factors = {
    "car": 0.2,
    "motorcycle": 0.1,
    "bus": 0.3,
    "Trucks": 0.1,
    "Airplane": 9.0,
    "Ship": 0.2,
    "Train": 0.6,
    "Deforestation": 5.0,
    "Logging": 3.0,
    "diesel generators": 7.0,
    "beef": 27.0,
    "dairy": 3.0,
    "chicken": 6.9,
    "pork": 5.8,
    "vegetables": 2.0,
    "fruits": 1.4,
    "plastic": 3.0,
    "paper": 1.0,
    "glass": 2.0
}

# Recommendations based on emissions
recommendations = {
    "transportation": {
        "car": "Consider carpooling or using public transportation to reduce emissions.",
        "motorcycle": "Consider using alternative transportation modes like cycling or walking.",
        "bus": "Using public transportation is a great choice for reducing carbon emissions.",
        "Trucks": "Promote the development of electric and hybrid trucks for short-distance and urban logistics.",
        "Airplane": "Explore alternative transportation options for shorter distances, such as high-speed trains, to reduce reliance on air travel.",
        "Ship": "Promote the use of shore power and onshore electricity infrastructure in ports to reduce emissions during port stays",
        "Train": "Invest in the electrification of train networks to reduce reliance on diesel-powered trains.",
        "Deforestation": "Support sustainable forestry practices, including selective logging and reforestation initiatives.",
        "diesel generators": "Transition to cleaner and more efficient power generation options like natural gas generators or renewable energy sources.",
        "logging": "Promote the use of innovative technologies like non-destructive testing to maximize timber utilization and minimize waste.",


    },
    "food": {
        "beef": "Reduce consumption of beef as it has a high carbon footprint. Choose more plant-based alternatives.",
        "dairy": "Promote plant-based diets or incorporate more plant-based options in meals. Encourage sustainable and regenerative livestock practices, such as rotational grazing and feed optimization. Because Dairy is gotten from animals most of the time.",
        "chicken": "Choose chicken as a lower carbon footprint alternative to beef.",
        "pork": "Opt for pork as a lower carbon footprint alternative to beef.",
        "vegetables": "Include more vegetables in your diet. They have a lower carbon footprint compared to meat.",
        "fruits": "Include more fruits in your diet. They have a lower carbon footprint compared to meat."
    },
    "waste": {
        "plastic": "Reduce the use of plastic and opt for reusable or biodegradable alternatives.",
        "paper": "Recycle paper and choose recycled paper products.",
        "glass": "Recycle glass bottles and jars to reduce waste and conserve resources."
    }
}

def calculate_carbon_emission(distance, vehicle_type, food_items, waste_items):
    emission_transportation = distance * emission_factors[vehicle_type]
    emission_food = sum(emission_factors[food_item] for food_item in food_items)
    emission_waste = sum(emission_factors[waste_item] for waste_item in waste_items)

    total_emission = emission_transportation + emission_food + emission_waste

    return total_emission


def index(request):
    if request.method == 'POST':
        distance = float(request.POST['distance'])
        vehicle_type = request.POST['vehicle_type']
        food_items = request.POST.getlist('food_items')
        waste_items = request.POST.getlist('waste_items')

        emission_transportation = vehicle_type
        emission_food = food_items
        emission_waste = waste_items

        total_emission = calculate_carbon_emission(distance, vehicle_type, food_items, waste_items)

        recommendations_list = get_recommendations(emission_transportation, emission_food, emission_waste)

        return render(request, 'result.html', {
            'total_emission': total_emission,
            'emission_transportation': emission_transportation,
            'emission_food': emission_food,
            'emission_waste': emission_waste,
            'recommendations_list': recommendations_list
        })

    return render(request, 'index.html')

def get_recommendations(emission_transportation, emission_food, emission_waste):
    recommendations_list = []
    print(emission_transportation)
    print(emission_food)
    print(emission_waste)
    for transportation_item in emission_transportation:
        if transportation_item in recommendations["transportation"]:
            recommendations_list.append(recommendations["transportation"][transportation_item])


    for food_item in emission_food:
        if food_item in recommendations["food"]:
            recommendations_list.append(recommendations["food"][food_item])

    
    for waste_item in emission_waste:
        if waste_item in recommendations["waste"]:
            recommendations_list.append(recommendations["waste"][waste_item])

    return recommendations_list

    
from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth import login, logout

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')  # Replace 'home' with the URL name of your home page
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')  # Replace 'home' with the URL name of your home page
    else:
        form = UserCreationForm()
    return render(request, 'registration.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')  # Replace 'home' with the URL name of your home page

def blog_view(request):
   
    return (request, 'home.html')

def home_view(request):
   
    return (request, 'home.html')

