from django.contrib import admin

from .models import MyModel

admin.site.register(MyModel)
